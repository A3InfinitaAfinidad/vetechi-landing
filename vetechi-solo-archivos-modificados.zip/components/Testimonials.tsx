'use client';

import { SHOW_GOOGLE_RATING, TESTIMONIALS } from '@/utils/constants';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { useLocale, useTranslations } from 'next-intl';
import { useState } from 'react';

export default function Testimonials() {
  const locale = useLocale();
  const t = useTranslations('testimonials');
  const isEs = locale === 'es';
  const [current, setCurrent] = useState(0);
  const visibleTestimonials = TESTIMONIALS.filter((item) => !item.temporarilyHidden);

  if (visibleTestimonials.length === 0) return null;

  const testimonial = visibleTestimonials[current];
  const text = isEs ? testimonial.es : testimonial.en;

  const nextTestimonial = () => {
    setCurrent((prev) => (prev + 1) % visibleTestimonials.length);
  };

  const prevTestimonial = () => {
    setCurrent((prev) => (prev - 1 + visibleTestimonials.length) % visibleTestimonials.length);
  };

  return (
    <section id="testimonios" className="py-20 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-1 h-6 bg-accent-500"></div>
            <p className="font-subtitle font-bold text-accent-900 uppercase text-sm">
              {isEs ? 'Lo que dicen nuestras familias' : 'What Our Families Say'}
            </p>
          </div>
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-dark-900 mb-2">
            {SHOW_GOOGLE_RATING
              ? (isEs ? '4.8/5 ⭐ en Google • 42 reseñas' : '4.8/5 ⭐ on Google • 42 reviews')
              : t('title')}
          </h2>
        </div>

        {/* Testimonial Carousel */}
        <div
          key={current}
          className="bg-gray-50 p-8 sm:p-12 rounded-lg border border-gray-200"
        >
          {/* Stars */}
          <div className="flex gap-1 mb-6">
            {[...Array(testimonial.rating)].map((_, i) => (
              <Star key={i} size={24} className="fill-accent-500 text-accent-500" />
            ))}
          </div>

          {/* Text */}
          <p className="text-xl md:text-2xl font-serif italic text-dark-900 leading-relaxed mb-6 text-center">
            &quot;{text}&quot;
          </p>

          {/* Author */}
          <div className="border-t border-gray-300 pt-6">
            <p className="font-subtitle font-bold text-dark-900">{testimonial.author}</p>
            <p className="text-sm text-text">{testimonial.location}</p>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-center items-center gap-6 mt-8">
          <button
            onClick={prevTestimonial}
            className="bg-gray-200 text-dark-900 w-12 h-12 rounded-full flex items-center justify-center hover:bg-primary-400 hover:text-white transition-all min-w-[48px] min-h-[48px]"
            aria-label="Anterior"
          >
            <ChevronLeft size={20} />
          </button>

          <div className="flex gap-2">
            {visibleTestimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className="group min-w-[48px] min-h-[48px] flex items-center justify-center"
                aria-label={`Testimonio ${i + 1}`}
              >
                <div
                  className={`h-3 rounded-full transition-all ${
                    i === current ? 'bg-primary-600 w-8' : 'bg-gray-300 w-3 group-hover:bg-primary-400'
                  }`}
                />
              </button>
            ))}
          </div>

          <button
            onClick={nextTestimonial}
            className="bg-gray-200 text-dark-900 w-12 h-12 rounded-full flex items-center justify-center hover:bg-primary-400 hover:text-white transition-all min-w-[48px] min-h-[48px]"
            aria-label="Siguiente"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </section>
  );
}
