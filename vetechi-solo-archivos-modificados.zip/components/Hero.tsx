import { BUSINESS_DATA, HOURS_ROWS, SHOW_GOOGLE_RATING, STATS } from '@/utils/constants';
import { Clock, MapPin, PawPrint, Phone, Star, Stethoscope } from 'lucide-react';
import { SiWhatsapp } from 'react-icons/si';
import { getLocale, getTranslations } from 'next-intl/server';
import { preload } from 'react-dom';

const IconMap = {
  Stethoscope,
  Star,
  Clock,
  PawPrint,
};

export default async function Hero() {
  preload('/images/optimized/hero/hero-bg-mobile-lcp.avif', { as: 'image', fetchPriority: 'high', media: '(max-width: 768px)' });
  preload('/images/optimized/hero/hero-bg-lcp.avif', { as: 'image', fetchPriority: 'high', media: '(min-width: 769px)' });

  const t = await getTranslations('hero');
  const locale = await getLocale();
  const isEs = locale === 'es';
  const stats = (isEs ? STATS.es : STATS.en).filter(
    (stat) => SHOW_GOOGLE_RATING || stat.icon !== 'Star',
  );
  const hoursRows = isEs ? HOURS_ROWS.es : HOURS_ROWS.en;

  return (
    <section id="inicio" className="relative flex min-h-screen items-center overflow-hidden bg-dark-900 pb-8 pt-24">
      <div className="absolute inset-0 z-0" aria-hidden="true">
        <picture>
          <source media="(max-width: 768px)" srcSet="/images/optimized/hero/hero-bg-mobile-lcp.avif" type="image/avif" />
          <source media="(min-width: 769px)" srcSet="/images/optimized/hero/hero-bg-lcp.avif" type="image/avif" />
          <img
            src="/images/optimized/hero/hero-bg.webp"
            alt=""
            className="absolute inset-0 h-full w-full object-cover"
            fetchPriority="high"
            decoding="async"
            sizes="100vw"
          />
        </picture>
        <div className="absolute inset-0 bg-gradient-to-r from-dark-900/95 via-dark-900/85 to-dark-900/75" />
        <div
          className="absolute inset-0 opacity-60"
          style={{ background: 'radial-gradient(circle at 30% 50%, rgba(27, 59, 47, 0.4) 0%, transparent 70%)' }}
        />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8 lg:gap-7">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1fr)_400px] lg:items-center lg:gap-10">
            <div className="min-w-0 space-y-5">
              <div className="inline-flex items-center gap-3 rounded-full border border-[#C5A77A]/40 bg-[#C5A77A]/10 px-5 py-2 shadow-[0_0_15px_rgba(197,167,122,0.15)] backdrop-blur-md">
                <MapPin size={14} className="text-accent-500" aria-hidden="true" />
                <span className="text-[11px] font-black uppercase tracking-[0.2em] text-white">
                  {isEs ? 'David, Chiriquí · Panamá' : 'David, Chiriquí · Panama'}
                </span>
              </div>

              <h1 className="font-display font-extrabold tracking-tight">
                <span className="block text-5xl leading-[0.98] text-white sm:text-6xl md:text-7xl lg:text-8xl">
                  {t('title')}
                </span>
                <span className="block text-5xl font-serif italic leading-[0.98] text-accent-500 sm:text-6xl md:text-7xl lg:text-8xl">
                  {t('brand')}
                </span>
                <span className="mt-3 block text-2xl font-semibold leading-snug text-white sm:text-3xl lg:text-4xl">
                  {t('headline')}
                </span>
              </h1>

              <p className="max-w-xl text-lg leading-relaxed text-gray-100 sm:text-xl">
                {t('subheadline')}
              </p>

              {SHOW_GOOGLE_RATING && (
                <div className="flex flex-wrap items-center gap-3 text-sm font-medium text-white/95">
                  <div className="flex gap-1" aria-hidden="true">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} size={16} className="fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <span>
                    <strong className="font-bold text-white">4.8/5</strong>{' '}
                    {isEs ? 'en Google (42 reseñas)' : 'on Google (42 reviews)'}
                  </span>
                </div>
              )}

              <div className="flex flex-col gap-3 pt-1 sm:flex-row sm:flex-wrap">
                <a
                  href={`${BUSINESS_DATA.whatsapp}?text=${encodeURIComponent(isEs ? BUSINESS_DATA.whatsappMessages.info.es : BUSINESS_DATA.whatsappMessages.info.en)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex min-h-[52px] items-center justify-center gap-3 rounded-xl bg-primary-700 px-6 py-3 text-center text-base font-bold text-white shadow-[0_0_20px_rgba(34,197,94,0.24)] transition-colors hover:bg-primary-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white sm:text-lg"
                >
                  <SiWhatsapp size={20} aria-hidden="true" />
                  <span>{t('cta1')}</span>
                </a>
                <a
                  href={BUSINESS_DATA.phoneHref}
                  aria-label={isEs ? 'Llamar por urgencia fuera del horario presencial' : 'Call for an emergency outside in-person hours'}
                  className="flex min-h-[52px] items-center justify-center gap-3 rounded-xl border border-white/50 bg-white/5 px-6 py-3 text-center text-base font-bold text-white backdrop-blur-sm transition-colors hover:bg-white/15 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white sm:text-lg"
                >
                  <Phone size={20} className="text-emergency motion-safe:animate-pulse" aria-hidden="true" />
                  <span>{t('cta2')}</span>
                </a>
              </div>
            </div>

            <aside
              aria-label={t('hoursHeading')}
              className="w-full rounded-3xl border border-white/20 bg-dark-900/70 p-6 text-white shadow-2xl backdrop-blur-xl sm:p-7 lg:w-[400px] lg:shrink-0"
            >
              <h2 className="mb-3 flex items-center gap-3 text-base font-bold text-accent-400 sm:text-lg">
                <Clock size={21} aria-hidden="true" />
                <span>{t('hoursHeading')}</span>
              </h2>
              <dl className="divide-y divide-white/15 text-sm sm:text-base">
                {hoursRows.map((row) => (
                  <div key={row.day} className="flex items-center justify-between gap-4 py-3">
                    <dt className="text-gray-100">{row.day}</dt>
                    <dd className="whitespace-nowrap text-right font-semibold tabular-nums text-white">{row.time}</dd>
                  </div>
                ))}
              </dl>

              <div className="mt-5 rounded-2xl border border-white/15 bg-dark-900/70 p-4 sm:p-5">
                <h3 className="text-sm font-bold text-white sm:text-base">{t('afterHoursLabel')}</h3>
                <p className="mt-2 text-sm leading-relaxed text-gray-100">
                  {isEs
                    ? 'Fuera del horario presencial, llama por una urgencia.'
                    : 'After in-person hours, call for an emergency.'}
                </p>
                <a
                  href={BUSINESS_DATA.phoneHref}
                  className="mt-3 inline-flex min-h-[44px] items-center text-xl font-bold tabular-nums text-accent-400 underline-offset-4 hover:underline sm:text-2xl"
                >
                  {BUSINESS_DATA.phone}
                </a>
              </div>
            </aside>
          </div>

          <div className="glassmorphism relative flex w-full flex-col items-center justify-around gap-5 overflow-hidden rounded-[2rem] p-4 shadow-2xl sm:flex-row sm:p-5">
            {stats.map((stat) => {
              const Icon = IconMap[stat.icon as keyof typeof IconMap];
              return (
                <div key={stat.label} className="relative z-10 flex items-center gap-3 text-center sm:flex-col sm:gap-1">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-accent-500">
                    {Icon && <Icon size={20} strokeWidth={2.5} aria-hidden="true" />}
                  </div>
                  <div className="sm:text-center">
                    <div className="text-lg font-display font-black leading-tight text-white">{stat.value}</div>
                    <div className="text-[10px] font-bold uppercase leading-tight tracking-[0.12em] text-gray-100 sm:text-[11px]">
                      {stat.label}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
